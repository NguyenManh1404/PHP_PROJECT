
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ẨM THỰC</title>
</head>
<body>
    <?php 
    include_once 'header1.php' ;
    ?>
    <br>
    <?php 
    include_once 'content.php';
    ?>
</body>
<br>
<footer>    
    <?php include_once 'footer.php' ?>
</footer>
</html>

<?php 
    $_SESSION['user_name']=null;
?>
